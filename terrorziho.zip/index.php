<!DOCTYPE html>
<html>
<head>
	<title>SRC TERRORZINHO</title>
</head>
<body>
	<b>EXAMPLES !</b>
	<p>este bot foi desenvolvido em php , esta no modo avançado , caso vc seja novo no ramo de desenvolvimento web (back-end ´php´) algumas functions seram dificies de entender !</p>

	<b> o bot usa o web hook do telegram !</b>
	<li>ATENÇÃO VC DEVE ALTERA O CONTEÚDO DO token.txt coloque o token do seu bot la ! </li>
	<li>para ativa o web hook entra no arquivo principal , no meu caso e terrorzinho.php e envie o comando ?setweb=true via get (terrorzinho?setweb=true)</li>
	<li>o resto vc aprendera com o tempo ! , duvidas de qualquer comando entre em contato comigo , user em confi.json ou entre na pagina do telegam <a href="https://core.telegram.org/bots/api ">entra na pagina</a></li>
</body>
</html>