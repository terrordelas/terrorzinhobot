<?php


$mae = file("./xingamae.txt");

$lista = [];
$file_handle = fopen("./xingamae.txt", "r");
	while (!feof($file_handle)) {
		$line = fgets($file_handle);

		$line = str_replace(array('\r\n',"\r\n","\r","\n"), '', $line);
		if (!empty($line)){
			$lista[] = $line;
		}
}


echo $lista[array_rand($lista)];